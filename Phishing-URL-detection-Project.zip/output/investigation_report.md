# Phishing Investigation Report

**Subject:** Urgent! Your Account Will Be Locked
**From:** support@m1crosoft-security.com
**Date:** 1970-01-01 00:00:00+00:00

## Extracted URLs
- https://m1crosoft-security.com/login-verify � VT: {'url': 'https://m1crosoft-security.com/login-verify', 'source': 'local', 'malicious': None, 'notes': 'VT_API not configured'}

## Attachments